.onAttach=function(libname,pkgname){
   packageStartupMessage("Loaded softImpute ", as.character(packageDescription("softImpute")[["Version"]]),"\n")
}
