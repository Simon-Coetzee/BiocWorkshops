#
# --- Test pdata.R ---
#

## test.pdata <- function() {
##     # function(data,type,comment,metadata)
## }

## test.check_pdata <- function() {
## }

## test.extract.pdata <- function() {
##     # test "[" and "[["
## }

## test.assign.pdata <- function() {
##     # test "[<-" and "[[<-"
## }

## test.plot.pdata <- function() {
## }
