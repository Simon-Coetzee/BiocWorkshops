#
# --- Test methods-oldclasses.R ---
#

#test.reorder.phylo <- function() {
#    # function(x, order = 'cladewise')
#}

