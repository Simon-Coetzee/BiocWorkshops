
library(testthat)
test_check("phylobase")
