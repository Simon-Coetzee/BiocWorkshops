
# BiocAnno2018

A repository for the annotation workshop at BioC2018
