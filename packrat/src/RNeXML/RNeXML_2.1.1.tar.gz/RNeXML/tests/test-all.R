library("testthat")
Sys.setenv("_R_CHECK_LENGTH_1_CONDITION_" = TRUE)
test_check("RNeXML")


